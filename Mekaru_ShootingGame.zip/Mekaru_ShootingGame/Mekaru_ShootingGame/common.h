#pragma once

struct T_Location
{
    float x;
    float y;
};